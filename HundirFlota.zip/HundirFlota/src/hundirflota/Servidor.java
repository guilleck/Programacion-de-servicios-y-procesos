package hundirflota;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
	public static void main(String[] args) {
        Tablero tablero = new Tablero();
        try (ServerSocket serverSocket = new ServerSocket(6001)) {
            System.out.println("Servidor iniciado en el puerto 6000.");
            try (Socket clienteSocket = serverSocket.accept();
                 BufferedReader entrada = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));
                 PrintWriter salida = new PrintWriter(clienteSocket.getOutputStream(), true)) {

                System.out.println("Cliente conectado.");
                String mensaje;
                while ((mensaje = entrada.readLine()) != null) {
                    String[] partes = mensaje.split(",");
                    int x = Integer.parseInt(partes[0]);
                    int y = Integer.parseInt(partes[1]);

                    if (tablero.disparar(x, y)) {
                        salida.println("Hundido");
                    } else {
                        salida.println("Agua");
                    }

                    if (!tablero.quedanBarcos()) {
                        salida.println("Ganaste");
                        break;
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error en el servidor: " + e.getMessage());
        }
    }
}
