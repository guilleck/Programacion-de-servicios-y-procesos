package hundirflota;

import java.io.*;
import java.net.*;
import java.util.Random;

public class Tablero {
	private final int[][] tablero;
    private final int TAMANO = 10;
    private final int NUM_BARCOS = 10;

    public Tablero() {
        tablero = new int[TAMANO][TAMANO];
        colocarBarcos();
    }

    private void colocarBarcos() {
        Random random = new Random();
        int colocados = 0;

        while (colocados < NUM_BARCOS) {
            int x = random.nextInt(TAMANO);
            int y = random.nextInt(TAMANO);

            if (tablero[x][y] == 0) { // Celda vacía
                tablero[x][y] = 1; // Colocar barco
                colocados++;
            }
        }
    }

    public boolean disparar(int x, int y) {
        if (x < 0 || x >= TAMANO || y < 0 || y >= TAMANO) {
            return false; // Disparo fuera de límites
        }
        if (tablero[x][y] == 1) {
            tablero[x][y] = -1; // Barco hundido
            return true;
        }
        return false; // Agua
    }

    public boolean quedanBarcos() {
        for (int i = 0; i < TAMANO; i++) {
            for (int j = 0; j < TAMANO; j++) {
                if (tablero[i][j] == 1) {
                    return true;
                }
            }
        }
        return false;
    }
}
