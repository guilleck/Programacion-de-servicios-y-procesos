package hundirflota;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Cliente {
	public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 6001);
             BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter salida = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Conectado al servidor.");

            int intentos = 20; // Número de intentos permitidos

            while (intentos > 0) {
                System.out.println("Ingresa las coordenadas (x,y): ");
                String input = teclado.readLine();
                salida.println(input);

                String respuesta = entrada.readLine();
                System.out.println("Respuesta del servidor: " + respuesta);

                if (respuesta.equals("Ganaste")) {
                    System.out.println("¡Felicidades! Has hundido todos los barcos.");
                    break;
                }

                intentos--;
                System.out.println("Intentos restantes: " + intentos);
            }

            if (intentos == 0) {
                System.out.println("Juego terminado. No te quedan más intentos.");
            }
        } catch (IOException e) {
            System.err.println("Error en el cliente: " + e.getMessage());
        }
    }
}
